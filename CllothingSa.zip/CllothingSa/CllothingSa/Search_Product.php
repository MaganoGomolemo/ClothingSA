<!DOCTYPE html>
<?php
	require_once'connection.php';
?>

<html lang="en">
    
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="bootstrap-4.6.0-dist\css\bootstrap.min.css">
		<title>Shopping</title>
		<link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/footers/">
		<script src="bootstrap-4.6.0-dist\js\bootstrap.bundle.js"></script>
		<script src="bootstrap-4.6.0-dist\js\bootstrap.js"></script>
		<link href="headers.css" rel="stylesheet">
		<link href="footers.css" rel="stylesheet">
    
		<style>
			.bd-placeholder-img 
			{
				font-size: 1.125rem;
				text-anchor: middle;
				-webkit-user-select: none;
				-moz-user-select: none;
				user-select: none;
			}
			
			body 
			{
				text-shadow: 0 .05rem .1rem rgba(0, 0, 0, .5);
				box-shadow: inset 0 0 5rem rgba(0, 0, 0, .5);
			}
		</style>
    
	</head>
   
    <body>
		<div class='container'>
			<header class='d-flex flex-wrap justify-content-center py-3 mb-3 border-bottom'>
				<div class='my-4'>
					<ul class='nav nav-pills'>
						<li class='nav-item'><a href='Search_Product.php' class='nav-link active' aria-current='page'>GET-ITEM</a></li>
						<li class='nav-item'><a href='home.php' class='nav-link text-secondary'>HOME</a></li>
						<li class='nav-item'><a href='brands.php' class='nav-link text-secondary'>BRANDS</a></li>
						<li class='nav-item'><a href='shopping.php' class='nav-link text-secondary'>SHOPPING</a></li>
						<li class='nav-item'><a href='Account.php' class='nav-link text-secondary' >ACCOUNT</a></li>						   
					</ul>
				</div>
						<form action='' method='GET' class='ml-5 d-flex align-items-center text-dark text-decoration-none'>
							<input type='search' name='txtsearch' class='form-control mx-3 my-2' placeholder='Search Brand' required>						
							<input type="submit" name='submit' value='Search' class='btn btn-outline-secondary' />
						</form>
			</header>
			  
			<div class="container-fluid">
				<div class="row">

				</div>
			  
				<div class="row">
					<div class="col-lg-4">

					</div>
					  
					<div class="col-lg-4 text-center">
						  
					</div>
					  
					<div class="col-lg-4 text-center">
						  <a href='ItemsCart.php' class='btn btn-secondary' data-target='#shopping-cart'>Cart</a>
					</div>
				</div>
			</div>			  
		</div>
		
		<section>
			<?php
				// Searching For Products 

					if(isset($_GET["submit"]))
					{
						$search_data_value = $_GET['txtsearch']; // Accessing a value
						
						$query = "Select * From tblproduct where name like '%$search_data_value%'";
							
						$result = mysqli_query($connect,$query);
													
						$Number_Of_Rows = mysqli_num_rows($result);	
												
						if($Number_Of_Rows > 0)
						{
															
							while($row = mysqli_fetch_assoc($result))
							{
								
							 echo  "<div class='container'>
									<div class='row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-3'>
										<div class='col'>
										<form method='POST' action='products.php?action=add&prod_id=".$row["prod_id"]."'>
											<div class = 'card shadow-sm my-2'>
												<img src= 'images/".$row['image']."' class='bd-placeholder-img card-img-top'>
													<div class='card-body'>
														<p class='card-text'>".$row['name']."<br>R ".$row['price']."</p>
														<div class='d-flex justify-content-between align-items-center'>
															<div class='btn-group'>
																<input type='text' class='form-control product-quantity mx-1' name='quantity' value='1' size='2'/>
																<input type='submit' name='Add_To_Cart' value='Add to Cart' class='btn btn-primary btnAddAction'/>
															</div>
													</div>												
												</div>
											</div>
											</form>
										</div>
									</div>	  
								  </div>";	
							}
						}
						else
						{
							echo "<h3 class='fw-light'> This Product Is Not Available At The Moment </h3>";
						}							
					}
			?>
		</section>
				  
		<?php 

			include'feature.php';
			include'footer.php'; 
		?> 
         
    </body>
</html>

