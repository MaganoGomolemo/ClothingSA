<?php

	$dbHost = 'localhost';
	$dbUsername = 'root';
	$Password = '';
	$dbName = 'shopping';

	$connect = mysqli_connect($dbHost,$dbUsername,$Password,$dbName);
	
	if(!$connect)
	{
		echo "<script>alert('Unsuccessful Connection')</script>";
	}
?>