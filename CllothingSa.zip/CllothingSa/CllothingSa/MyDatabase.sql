CREATE TABLE Categories
(      
    CategoryID INTEGER PRIMARY KEY IDENTITY(1,1),
    CategoryName VARCHAR(25),
    Description VARCHAR(255)
)
GO

CREATE TABLE Customers
(      
    CustomerID INTEGER PRIMARY KEY IDENTITY(1,1),
    CustomerName VARCHAR(50),
    ContactName VARCHAR(50),
    Address VARCHAR(50),
    City VARCHAR(20),
    PostalCode VARCHAR(10),
    Country VARCHAR(15)
);
GO

CREATE TABLE Employees
(
    EmployeeID INTEGER PRIMARY KEY IDENTITY(1,1),
    LastName VARCHAR(15),
    FirstName VARCHAR(15),
    BirthDate DATETIME,
    Photo VARCHAR(25),
    Notes VARCHAR(1024)
);
GO

CREATE TABLE Shippers(
    ShipperID INTEGER PRIMARY KEY IDENTITY(1,1),
    ShipperName VARCHAR(25),
    Phone VARCHAR(15)
);
GO

CREATE TABLE Suppliers(
    SupplierID INTEGER PRIMARY KEY IDENTITY(1,1),
    SupplierName VARCHAR(50),
    ContactName VARCHAR(50),
    Address VARCHAR(50),
    City VARCHAR(20),
    PostalCode VARCHAR(10),
    Country VARCHAR(15),
    Phone VARCHAR(15)
);
GO

CREATE TABLE Brands
(
	BrandID INTEGER PRIMARY KEY IDENTITY(1,1),
	BrandName VARCHAR(50),
	Description VARCHAR(150)
);
GO

CREATE TABLE Products(
    ProductID INTEGER PRIMARY KEY IDENTITY(1,1),
    ProductName VARCHAR(50),
    SupplierID INTEGER,
    CategoryID INTEGER,
    Unit VARCHAR(25),
	BrandID INTEGERl
    Price NUMERIC,
	FOREIGN KEY (CategoryID) REFERENCES Categories (CategoryID),
	FOREIGN KEY (SupplierID) REFERENCES Suppliers (SupplierID),
	FOREIGN KEY (BrandID) REFERENCES Brands (BrandID)
);
GO

CREATE TABLE Orders(
    OrderID INTEGER PRIMARY KEY IDENTITY(10248,1),
    CustomerID INTEGER,
    EmployeeID INTEGER,
    OrderDate DATETIME,
    ShipperID INTEGER,
    FOREIGN KEY (EmployeeID) REFERENCES Employees (EmployeeID),
    FOREIGN KEY (CustomerID) REFERENCES Customers (CustomerID),
    FOREIGN KEY (ShipperID) REFERENCES Shippers (ShipperID)
);
GO

CREATE TABLE OrderDetails(
    OrderDetailID INTEGER PRIMARY KEY IDENTITY(1,1),
    OrderID INTEGER,
    ProductID INTEGER,
    Quantity INTEGER,
	FOREIGN KEY (OrderID) REFERENCES Orders (OrderID),
	FOREIGN KEY (ProductID) REFERENCES Products (ProductID)
);
GO