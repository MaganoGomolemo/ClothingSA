<?php

$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'reglog';

$dbc = mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbName);

if(!$dbc)
{
	echo "<script>alert('Unsuccessful Connection')</script>";
}

?>
