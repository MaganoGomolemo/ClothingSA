<?php

	require_once 'Config.inc.php';
	require_once 'Functions.inc.php';

	if(isset($_POST["submit"]))
	{
		$FullName = $_POST["Name"];
		$Password = $_POST["Password"];
		
		// Error Handling
				
		if(emptyInputSignIn($FullName,$Password) !== false)
		{
			header("location: ../Account.php?error=emptyInputSignIn"); //LogIn.php
			exit();
		}
		
		LoginUser($dbc,$FullName,$Password); // Calling A Method And Passing Values As Parameters		
	}
	
	else
	{
		header("location: ../Account.php"); //LogIn.php
		exit();
	}

?>