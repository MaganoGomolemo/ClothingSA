<?php

	function emptyInputSignup($FullName, $ContactNumber, $EmailAddress, $Password)
	{
		$Result;
		
		if(empty($FullName) || empty($ContactNumber) || empty($EmailAddress) || empty($Password))
		{
			$Result = true;
		}
		else
		{
			$Result = false;
		}
		
		return $Result;		
	}
	
	function InvalidName($FullName)
	{
		$Result;
		
		if(!preg_match("/^[A-Za-z _]*[A-Za-z ]+[A-Za-z _]*$/", $FullName))
		{
			$Result = true;
		}
		else
		{
			$Result = false;
		}
		
		return $Result;	
	}
	
	function InvalidContactNumber($ContactNumber)
	{
		$Result;
		
		if(!preg_match("/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i",$ContactNumber))
		{
			$Result = true;
		}
		else
		{
			$Result = false;
		}
		
		return $Result;	
	}
	
	function InvalidEmailAddress($EmailAddress)
	{
		$Result;
		
		if(!filter_var($EmailAddress, FILTER_VALIDATE_EMAIL))
		{
			$Result = true;
		}
		else
		{
			$Result = false;
		}
		
		return $Result;	
	}
	
	function InvalidPassword($Password)
	{
		$Result;
		
		if(strlen(trim($Password)) <5) 
		{
			$Result = true;
		}
		 else
		{
			$Result = false;
		}
		
		return $Result;	
	}
	
	function NameExits($dbc, $FullName/*, $EmailAddress*/)
	{
		//$sql = "SELECT * FROM person WHERE FullName = ? OR EmailAddress =  ?;";	
		
		$sql = "SELECT * FROM person WHERE FullName = ?;";// OR EmailAddress =  ?;";	
		
		$stmt = mysqli_stmt_init($dbc); // prepare statements
		
		if(!mysqli_stmt_prepare($stmt,$sql))
		{
			header("location: ../Account.php?error=stmtfailed"); // It was first SignUp.php not account.php
			exit();
		}
		
		mysqli_stmt_bind_param($stmt, "s", $FullName, /*$EmailAddress*/ ); // Passing data from the user
		
		mysqli_stmt_execute($stmt); // Running the statements
		
		$Result = mysqli_stmt_get_result($stmt); // get the result from $stmt from line number 97
		
		if($Row = mysqli_fetch_assoc($Result)) // fetch data from database as associative array
		{
			return $Row;
		}
		
		else
		{
			$Result = false;
			return $Result;
		}
		
		mysqli_stmt_close($stmt); 
		
	}
	
	function CreateUser($dbc, $FullName, $ContactNumber, $EmailAddress, $Password)
	{
		$sql = "INSERT INTO person(FullName, ContactNumber, EmailAddress, Password) VALUES(?,?,?,?);";	
		
		$stmt = mysqli_stmt_init($dbc); // initialize new prepare statement using connection $dbc
		
		if(!mysqli_stmt_prepare($stmt, $sql))
		{
			header("location: ../Account.php?error=StmtFailed"); // signup.php
			exit();
		}
		
		$HashedPassword = password_hash($Password, PASSWORD_DEFAULT);
		
		mysqli_stmt_bind_param($stmt, "ssss", $FullName, $ContactNumber, $EmailAddress, $HashedPassword);
		
		mysqli_stmt_execute($stmt);
		
		mysqli_stmt_close($stmt);
		
		header("location: ../LogIn.php?error=None");			
		exit();		
	}
	
	function emptyInputSignIn($FullName, $Password)
	{
		$Result;
		
		if(empty($FullName) || empty($Password))
		{
			$Result = true;
		}
		else
		{
			$Result = false;
		}
		
		return $Result;		
	}
	
	function LoginUser($dbc,$FullName,$Password)
	{
		$NameExits = NameExits($dbc, $FullName/*, $FullName*/); 
		
		if($NameExits === false)
		{
			header("location: ../Account.php?error=wrongLogin"); //LogIn.php
			exit();
		}
		
		$PasswordHashed = $NameExits["Password"];
		
		$CheckPassword = password_verify($Password,$PasswordHashed);
		
		if($CheckPassword === false)
		{
			header("location: ../Account.php?error=wrongLogin"); //Password Don't match (LogIn.php)
			exit();
		}
				
		else if($CheckPassword === true)
		{
			session_start();   
								
			$_SESSION["Userid"] = $NameExits["UserID"];			
			$_SESSION["Fullname"] = $NameExits["FullName"];
			
			// Remember_Me Functionality
			
			if(isset($_POST["remember-me"]))
				{
					setcookie("usercookie", $_POST["Name"], time()+(86400*30));
				}
			
			else
			{
				if(!empty($_COOKIE["usercookie"]))
				{
					setcookie("usercookie", "");
				}
			}	
		}						
			header("location: ../home.php");
			exit();
		}		