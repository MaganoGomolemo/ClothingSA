<?php

	session_start(); // We have to start the session so that we can delete the session variable.
	session_unset(); // Unseting other sessions that you might have on the website.
	session_destroy(); // logout the user
	
	setcookie('usercookie', '', time()-86400*30);

	// After the user has logged out we will take the user to the sign-up page.
	
	echo '<script>alert("You Have Logged Out"  .' .$_SESSION["Fullname"].')</script>';
	header("location: ../Account.php");
	exit();
?>
