<?php
	
	require_once 'Config.inc.php';
	require_once 'Functions.inc.php';
	
	if(isset($_POST["submit"]))
	{
		$FullName = $_POST["Name"];
		$ContactNumber = $_POST["ContactNumber"];
		$EmailAddress = $_POST["EmailAddress"];
		$Password = $_POST["Password"];
				
		if(emptyInputSignup($FullName,$ContactNumber,$EmailAddress,$Password) !== false)
		{
			header("location: ../Account.php?error=emptyInputSignup"); //SignUp.php
			exit();
		}
		
		if(InvalidName($FullName) !== false)
		{
			header("location: ../Account.php?error=InvalidName");//SignUp.php
			exit();
		}
		
		if(InvalidContactNumber($ContactNumber) !== false)
		{
			header("location: ../Account.php?error=InvalidContactNumber");//SignUp.php
			exit();
		}
		
		if(InvalidEmailAddress($EmailAddress) !== false)
		{
			header("location: ../Account.php?error=InvalidEmailAddress");//SignUp.php
			exit();
		}
		
		if(InvalidPassword($Password) !== false)
		{
			header("location: ../Account.php?error=InvalidPassword");//SignUp.php
			exit();
		}
		
		if(NameExits($dbc, $FullName /*$EmailAddress*/) !== false)
		{
			header("location: ../Account.php?error=NameTaken");//SignUp.php
			exit();
		}
 
		CreateUser($dbc, $FullName, $ContactNumber, $EmailAddress, $Password);
		
	}

	else
	{
		header("location:  ../Account.php");//SignUp.php
		exit();
	}
