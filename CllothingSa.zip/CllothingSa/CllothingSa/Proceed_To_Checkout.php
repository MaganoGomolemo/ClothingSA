<?php
	session_start();
    
	require_once'connection.php';
    
	require_once'header.php';
	
	// When The User Is Logged In Display The Following Links To User
	
	if(isset($_SESSION["Fullname"]))
	{
		echo"
		<div class='container'>
            <header class='d-flex flex-wrap justify-content-center py-3 mb-3 border-bottom'>
				<div class='my-4'>			  
					<ul class='nav nav-pills'>		 			  
						<li class='nav-item'><a href='home.php' class='nav-link active' aria-current='page'>HOME</a></li>
						<li class='nav-item'><a href='brands.php' class='nav-link text-secondary'>BRANDS</a></li>
						<li class='nav-item'><a href='shopping.php' class='nav-link text-secondary'>SHOPPING</a></li>
						<li class='nav-item'><a href='includes/Logout.inc.php' class='nav-link text-secondary' >LOGOUT</a></li>		
						
					</ul>
				</div>
				
				<form action='Search_Product.php' method='GET' class='ml-5 d-flex align-items-center text-dark text-decoration-none'>
					<input type='search' name='txtsearch' class='form-control mx-3 my-2' placeholder='Search Brand' required>
					<input type='submit' name='submit' value='Search' class='btn btn-outline-secondary' />
				</form>
            </header>
        </div>";
	}
	else
	{
		// When The User Is Not Logged In Don't Display The Following Links
		
	  echo"
		<div class='container'>
            <header class='d-flex flex-wrap justify-content-center py-3 mb-3 border-bottom'>
				<div class='my-4'>			  
					<ul class='nav nav-pills'>		 			  
						<li class='nav-item'><a href='home.php' class='nav-link active' aria-current='page'>HOME</a></li>
						<li class='nav-item'><a href='brands.php' class='nav-link text-secondary'>BRANDS</a></li>
						<li class='nav-item'><a href='shopping.php' class='nav-link text-secondary'>SHOPPING</a></li>
						<li class='nav-item'><a href='Account.php' class='nav-link text-secondary' >ACCOUNT</a></li>
											
					</ul>
				</div>
				
				<form action='Search_Product.php' method='GET' class='ml-5 d-flex align-items-center text-dark text-decoration-none'>
					<input type='search' name='txtsearch' class='form-control mx-3 my-2' placeholder='Search Brand' required>
					<input type='submit' name='submit' value='Search' class='btn btn-outline-secondary' />
				</form>
            </header>
        </div>";		
	}

	// After A User Has Logged In Say Something To Welcome The User On The Website.	
	
		if(isset($_SESSION["Fullname"]))	
		{
			echo "<p justify-content'center'> Welcome To ClothingSa" ." " .$_SESSION["Fullname"]."</p>";
		}
	
?>

<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="bootstrap-4.6.0-dist\css\bootstrap.min.css">
    <title>HOME</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/footers/">
    <script src="bootstrap-4.6.0-dist\js\bootstrap.bundle.js"></script>
    <script src="bootstrap-4.6.0-dist\js\bootstrap.js"></script>
    <link href="headers.css" rel="stylesheet">
    <link href="footers.css" rel="stylesheet">
    
	<style>
        .bd-placeholder-img 
		{
			font-size: 1.125rem;
			text-anchor: middle;
			-webkit-user-select: none;
			-moz-user-select: none;
			user-select: none;
		}
        body 
		{
            text-shadow: 0 .05rem .1rem rgba(0, 0, 0, .5);
            box-shadow: inset 0 0 5rem rgba(0, 0, 0, .5);
		}

    </style>
	
    </head>
    <body>
	
	<div class="container-fluid">
		<div class="row">
		</div>
			
		<div class="row">
			<div class="col-lg-4">
			</div>
				
			<div class="col-lg-4 text-center">		  
			</div>
				
		<div class="col-lg-4 text-center">
			<a href='products.php' class='btn btn-secondary' data-target='#shopping-cart'>Cart</a>
			
			
		</div>
			</div>
	</div>	
	
        <section class="py-5 text-center container">
            <div class="row py-lg-5">
                <div class="col-lg-6 col-md-8 mx-auto">
					<form method="POST" action="">
						<h3 class="fw-light">Proceed To CheckOut</h3>
						<p class="lead text-muted"></p>

					</form>
                </div>
            </div>
        </section>
                 
        <?php
			include'feature.php';
			include'footer.php'; 
         ?>
    </body>
</html>