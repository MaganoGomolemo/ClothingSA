<div class="container px-4 py-5 my-5" id="hanging-icons">
    <h2 class="pb-2 border-bottom">Clothing SA</h2>
    <div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
      <div class="col d-flex align-items-start text-center my-3">
        <div>
		<form action='brands.php' method='POST'>
          <h3>Top Selling</h3>
          <p>Check the top 8 Clothing SA brands. You can tell whether it's loved by its sales, check all the brands that are regarded as top selling in South Africa</p>
          <button name="btnTopSelling" class="btn btn-primary">
            Top Selling
          </button>
		  </form>
        </div>
      </div>
      <div class="col d-flex align-items-start text-center my-3">
        <div>
		<form action='brands.php' method='POST'>
          <h3>Recommended</h3>
          <p>Look at other options besides your desired one, you don't what you can find. Recommended brands have that suprise factor that works for them, Let it work on you.</p>
          <button name="btnRecommended" class="btn btn-primary">
            Recommended
          </button>
		  </form>
        </div>
      </div>
      <div class="col d-flex align-items-start text-center my-3">
        <div>
		<form action='brands.php' method='POST'>
          <h3>Sales</h3>
          <p>They are not top selling but they still selling, even cheaper now. We give you the brands that are regarded as the foundation for the Clothing SA.</p>
          <button name="btnSales" class="btn btn-primary">Check Sales</button>
		  </form>
        </div>
      </div>
    </div>
 </div>