<?php

	session_start();
    
	require_once'connection.php';
	
	// When The User Is Logged In Display The Following Links To User
	
	if(isset($_SESSION["Fullname"]))
	{
		echo"
		<div class='container'>
            <header class='d-flex flex-wrap justify-content-center py-3 mb-3 border-bottom'>
				<div class='my-4'>			  
					<ul class='nav nav-pills'>
						<li class='nav-item'><a href='Account.php' class='nav-link active' aria-current='page'>ACCOUNT</a></li>
						<li class='nav-item'><a href='home.php' class='nav-link text-secondary'>HOME</a></li>
						<li class='nav-item'><a href='brands.php' class='nav-link text-secondary'>BRANDS</a></li>
						<li class='nav-item'><a href='shopping.php' class='nav-link text-secondary'>SHOPPING</a></li>
						<li class='nav-item'><a href='includes/Logout.inc.php' class='nav-link text-secondary'>LOGOUT</a></li>				
					</ul>
				</div>
				
				<form action='Search_Product.php' method='GET' class='ml-5 d-flex align-items-center text-dark text-decoration-none'>
					<input type='search' name='txtsearch' class='form-control mx-3 my-2' placeholder='Search Brand' required>
					<input type='submit' name='submit' value='Search' class='btn btn-outline-secondary' />
				</form>
            </header>
        </div>";
	}
	else
	{
		// When The User Is Not Logged In Don't Display The Following Links
		
	  echo"
		<div class='container'>
            <header class='d-flex flex-wrap justify-content-center py-3 mb-3 border-bottom'>
				<div class='my-4'>			  
					<ul class='nav nav-pills'>		 			  
						<li class='nav-item'><a href='home.php' class='nav-link text-secondary' >HOME</a></li>
						<li class='nav-item'><a href='brands.php' class='nav-link text-secondary'>BRANDS</a></li>
						<li class='nav-item'><a href='shopping.php' class='nav-link text-secondary'>SHOPPING</a></li>
						<li class='nav-item'><a href='Account.php' class='nav-link active' aria-current='page' >ACCOUNT</a></li>
					</ul>
				</div>
				
				<form action='Search_Product.php' method='GET' class='ml-5 d-flex align-items-center text-dark text-decoration-none'>
					<input type='search' name='txtsearch' class='form-control mx-3 my-2' placeholder='Search Brand' required>
					<input type='submit' name='submit' value='Search' class='btn btn-outline-secondary' />
				</form>
            </header>
        </div>";		
	}

?>

<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-4.6.0-dist\css\bootstrap.min.css">
    <title> Account </title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/footers/">
    <script src="bootstrap-4.6.0-dist\js\bootstrap.bundle.js"></script>
    <link href="headers.css" rel="stylesheet">
    <link href="footers.css" rel="stylesheet">
    <style>
        .bd-placeholder-img 
		{
			font-size: 1.125rem;
			text-anchor: middle;
			-webkit-user-select: none;
			-moz-user-select: none;
			user-select: none;
		}
        body 
		{
            text-shadow: 0 .05rem .1rem rgba(0, 0, 0, .5);
            box-shadow: inset 0 0 5rem rgba(0, 0, 0, .5);
		}

    </style>
    </head>
    <body>
		
		<div class="container-fluid">
			<div class="row">
			</div>
			
			<div class="row">
				<div class="col-lg-4">
				</div>
				
				<div class="col-lg-4 text-center">		  
				</div>
				
				<div class="col-lg-4 text-center">
					<a href='products.php' class='btn btn-secondary' data-target='#shopping-cart'>Cart</a>
				</div>
			</div>
		</div>
		
        <section>
           <div class="container-fluid">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
						<h4 class='text-center'> Sign-Up & Sign-In </h4>
							<div class="col-md-12">
								<div class="row">
										<div class="col-md-4">
				
											<form class="form-signin" action="includes/Reglog.inc.php" method="POST">
	
												<img class="mb-4" src="../assets/brand/bootstrap-logo.svg" alt="" width="72" height="57">
													
												<h1 class="h3 mb-3 fw-normal">Sign-Up</h1>
														
												<div class="form-floating">
													<input type="text" class="form-control" id="floatingInput" name="Name" placeholder="Full Name">
													<label for="floatingInput">Full Name</label>
												</div>
															
												<div class="form-floating">
													<input type="text" class="form-control" id="floatingInput" name="ContactNumber" placeholder="Contact Number">
													<label for="floatingInput">Contact Number</label>
												</div>
																
												<div class="form-floating">
													<input type="email" class="form-control" id="floatingInput" name="EmailAddress" placeholder="name@example.com">
													<label for="floatingInput">Email Address</label>
												</div>
																	
												<div class="form-floating">
													<input type="Password" class="form-control" id="floatingPassword" name="Password" placeholder="Password">
													<label for="floatingPassword">Password</label>
												</div>

												<button class="w-100 btn btn-lg btn-primary" name="submit" type="submit">Sign-Up</button>
		
											</form>
				
											<?php
										
											if(isset($_GET["error"]))
											{
												if($_GET["error"] == "emptyInputSignup")
												{
													echo "<p> Fill In All Fields! </p>";
												}
												
												else if($_GET["error"] == "InvalidName")
												{
													echo "<p> Enter A Proper Name </p>";
												}
												
												else if($_GET["error"] == "InvalidContactNumber")
												{
													echo "<p> Enter A Proper Contact Number! </p>";
												}
												
												else if($_GET["error"] == "InvalidEmailAddress")
												{
													echo "<p> Enter A Proper Email Address! </p>";
												}
												
												else if($_GET["error"] == "InvalidPassword")
												{
													echo "<p> Password Must Be More Than 5 Letters </p>";
												}
												
												else if($_GET["error"] == "stmtfailed")
												{
													echo "<p> Something Went Wrong Try Again! </p>";
												}
												
												else if($_GET["error"] == "NameTaken")
												{
													echo "<p> Username Already Taken! </p>";
												}
												
												else if($_GET["error"] == "None")
												{
													echo "<p> You have Signed-Up! </p>";
												}
											}
										?>		

										</div>
								</div>
							</div>
					</div>
					</div>
					</div>
					</div>
					
					<div class="container-fluid">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
					
							<div class="col-md-12">
								<div class="row">
						<div class="col-md-6">
								
								
							<form class="form-signin" action="includes/Logreg.inc.php" method="POST">
						
								<img class="mb-4" src="../assets/brand/bootstrap-logo.svg" alt="" width="72" height="57">
							
								<h1 class="h3 mb-3 fw-normal">Sign-In</h1>

								<div class="form-floating">
									<input type="text" name="Name" class="form-control" id="floatingInput" placeholder="Full Name" value=" <?php if(isset($_COOKIE['usercookie'])) {echo $_COOKIE['usercookie'];} ?>" />
									<label for="floatingInput">Full Name</label>
								</div>
							
								<div class="form-floating">
									<input type="Password" name="Password" class="form-control" value="" id="floatingPassword" placeholder="Password"/>
									<label for="floatingPassword">Password</label>
								</div>	

								<div class="checkbox mb-3">
									<label>
									<input type="checkbox" name="remember-me" <?php if(isset($_COOKIE["usercookie"])) {?> checked <?php } ?> /> Remember me 
									</label>
								</div>
							
								<button class="w-100 btn btn-lg btn-primary" name="submit" type="submit">Sign-In</button>
							
							</form>
								
								<?php
	   
								if(isset($_GET["error"]))
								{
									if($_GET["error"] == "emptyInputSignIn")
									{
										echo "<p> Fill In All Fields! </p>";
									}
							
									else if($_GET["error"] == "wrongLogin")
									{
										echo "<p> Incorrect information! </p>";
									}
									
									else if($_GET["error"] == "InvalidPassword")
									{
										echo "<p> Password Must Be More Than 5 Letters </p>";
									}
									
									else if($_GET["error"] == "InvalidName")
									{
										echo "<p> Enter A Proper Name </p>";
									}
								}
									  
							   ?>
				
						</div>
				</div>
			</div>
		</div>
		</div>
		</div>
		</div>
		
        </section>
                  
        <?php
			if(isset($_POST["btnBrands"]))
			{
				echo "<script>window.location.replace('brands.php');</script>";
			}
			
			if(isset($_POST["btnShopNow"]))
			{
				echo "<script>window.location.replace('shopping.php');</script>";
			}
		
			 include'feature.php';
			 include'footer.php'; 
        ?>
    </body>
</html>