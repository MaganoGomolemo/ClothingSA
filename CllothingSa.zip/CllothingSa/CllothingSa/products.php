<?php
	require_once 'connection.php';
	require_once 'header.php';
	// Add To Cart Functionality
	
	if(isset($_POST["Add_To_Cart"]))
	{
		if(isset($_SESSION["shopping_cart"]))
		{
			$session_array_id = array_column($_SESSION['shopping_cart'], "id");
			
			if(!in_array($_GET['prod_id'], $session_array_id))
			{
				$count = count($_SESSION["shopping_cart"]);
				
				$session_array = array(
			
				'id'       => $_GET["prod_id"],
				"name"     => $_POST['name'],
				"price"    => $_POST['price'],
				"quantity" => $_POST['quantity']
			
				);
				$_SESSION["shopping_cart"][$count] = $session_array; 	
				
			}
			else
			{
				echo '<script>alert("Item Has Already Added To Shopping Cart")</script>';
			}	
		}
		else
		{
			$session_array = array(
			
				'id'       => $_GET["prod_id"],
				"name"     => $_POST['name'],
				"price"    => $_POST['price'],
				"quantity" => $_POST['quantity']
			
			);
			$_SESSION["shopping_cart"][0] = $session_array; 
			//echo '<script>alert("Item Added To Shopping Cart")</script>';	
		}
	}
?>

<!DOCTYPE html>
<html>
    <head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="bootstrap-4.6.0-dist\css\bootstrap.min.css">
		<script src="bootstrap-4.6.0-dist\js\bootstrap.js"></script>
		<script src="bootstrap-4.6.0-dist\js\bootstrap.bundle.js"></script>
		<title> Products </title>
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<link href="headers.css" rel="stylesheet">
		<link href="footers.css" rel="stylesheet">
	</head>
	
	<body>
	
	<div class="container-fluid">
			<div class="row">
			</div>
			
			<div class="row">
				<div class="col-lg-4">
				</div>
				
				<div class="col-lg-4 text-center">
				</div>
				
				<div class="col-lg-4 text-center">
					<!--<a href='ItemsCart.php' class='btn btn-secondary' data-target='#shopping-cart'>Cart</a>-->
				</div>
			</div>		
		</div>
	
	
		<div class="container-fluid">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
						<h4 class='text-center'> Shop </h4>
							<div class="col-md-12">
								<div class="row">
															
									<?php
										$query = "Select * From tblproduct ORDER BY prod_id ASC";
			  
										$result = mysqli_query($connect,$query);
								
										while($row = mysqli_fetch_array($result))
										{
											?>
										<div class="col-md-4">
										<form method='post' action='products.php?prod_id=<?php echo $row["prod_id"] ?>'>

											<img src= 'images/<?php echo $row["image"] ?>' style="height: 150px;">
											<h5 class="text-center"> <?php echo $row["name"] ?> </h5>                           
											<h5 class="text-center"> R <?php echo number_format($row["price"],2); ?> </h5>
											<input type="hidden" name="name" value="<?php echo $row["name"] ?> ">
											<input type="hidden" name="price" value="<?php echo $row["price"] ?> ">
											<input type="number" name="quantity" value="1" class="form-control">
											<input type="submit" name="Add_To_Cart" class="btn btn-warning btn-block my-2" value="Add To Cart">
										
										</form>
										</div>
										<?php }
							?>
								</div>
							</div>
					</div>
					
						<div class="col-md-6">
							<h3 class="text-center"> Item Details </h3>

									<table class='table table-bordered table-striped'>
										<tr>
											<th> ID </th>
											<th> Item Name </th>
											<th> Item Price </th>
											<th> Item Quantity </th>
											<th> Total Price </th>
											<th> Action </th>
										</tr>	
							<?php		
									
									if(!empty($_SESSION['shopping_cart']))
									{
										$total=0;
										foreach($_SESSION['shopping_cart'] as $key => $value)
										{
							?>				
												<tr>
													<td> <?php echo $value["id"]; ?> </td>
													<td> <?php echo $value["name"]; ?> </td>
													<td> R <?php echo $value["price"]; ?> </td>
													<td> <?php echo $value["quantity"]; ?> </td>
													<td> R <?php echo number_format((int)$value["price"] * (int)$value["quantity"],2); ?> </td>
													<td>
														<a href="products.php?action=remove&prod_id=<?php echo $value["id"]; ?>"> 
															<button class='btn tbn-danger btn-block'> Remove </button>
														</a>	
													</td>		
												</tr>
							<?php						
											$total = $total + (int)($value['quantity']) * (int)($value['price']);
											
										}
							?>			
											<tr>
												<td colspan='3'> </td>
												<td> </b> Total Price <b> </td>
												<td> R <?php echo number_format($total,2) ?> </td>
												<td>
													<a href='products.php?action=clearall'>
														<button class='btn btn-warning btn-block'> Clear </button>
													</a>
												</td>
											</tr>
										
							<?php			
									}
									
							?>
										<tr>
												<td colspan='3'> </td>
											<a href="Proceed_To_Checkout.php">
												<!--<button class='btn btn-warning btn-block'> Proceed To CheckOut </button>-->
											</a>
										</tr>
									</table>
						</div>
				</div>
			</div>
		</div>
		
			<?php
			
				if(isset($_GET['action']))
				{
					if($_GET['action'] == "clearall")
					{
						unset($_SESSION['shopping_cart']);
						echo '<script>alert("All Items Have Been Removed From Shopping Cart")</script>';
						echo '<script>window.location="products.php"</script>';
					}
					
					if($_GET['action'] == "remove")
					{
						foreach($_SESSION['shopping_cart'] as $key => $value)
						{
							if($value['id'] == $_GET['prod_id'])
							{
								unset($_SESSION['shopping_cart'][$key]);
								echo '<script>alert("Item Have Been Removed From Shopping Cart")</script>';
								echo '<script>window.location="products.php"</script>';
							}
						}
					}	
				}
					include 'feature.php'; 
					include 'footer.php';
			?>
	
	</body>

	</html>